#include<iostream>
#include<string>
#include <cctype>
using namespace std;

template <typename T>
class stack
{
    private:
        struct Node {
            T elem; // phần tử
            Node * next; // liên kết tới nút kế tiếp
            // Hàm tạo
            Node(T e, Node * n)
            {
                elem = e;
                next = n;
            }
        };
        Node * head;

    public:
        stack()
        {
            head = NULL;
        }

        T top()
        {
            return head->elem;
        }

        void push(T e)
        {
            // v là nút mới, trong đó v.next = head có
            // nghĩa là v trỏ tới nút đầu danh sách.
            Node * v = new Node(e, head);
            // Nút đầu danh sách bây giờ là v, vì vậy
            // phải cập nhật con trỏ head.
            head = v;
        }

        void pop()
        {
            // Giữ lại nút đầu danh sách
            Node * old = head;
            // Nhảy sang nút kế tiếp
            head = head->next;
            // Xóa nút đầu danh sách cũ
            delete old;
        }

        bool empty() {
            return (head == NULL);
        }

        ~stack()
        {
            while (!empty())
                {
                    pop();
                }
        }
};

template <typename T>
class vector
{
    private:
        int Size; // kích thước vector (số phần tử)
        int capacity; // dung lượng vector (sức chứa)
        T * Array; // con trỏ tới mảng chứa các phần tử
    public:
        vector(int initCapacity = 1000)
        {
            Size = 0;
            capacity = initCapacity;
            Array = new T[capacity];
            //cout<<"Khoi tao vung nho :"<<Array<<endl;
        }

        // Trả về kích thước vector
        int size() {
            return Size;
        }

        // index là chỉ số của phần tử cần truy nhập
        T & operator[](int index) {
            return Array[index];
        }

        // Đây là thao tác trợ giúp cho các thao tác chèn.
        // newCapacity là dung lượng mới (phải lớn hơn kích thước).
        void expand(int newCapacity) {
            if (newCapacity <= Size)
            return;
                T * old = Array; // old trỏ tới mảng cũ
                Array = new T[newCapacity]; // array trỏ tới mảng mới
                for (int i = 0; i < Size; i++)
                    Array[i] = old[i]; // sao chép cũ sang mới
                delete[] old; // xóa mảng cũ
                capacity = newCapacity; // đặt dung lượng mới
                //cout<<"Nang vung nho :"<<Array<<endl;
        }

        // newElement là phần tử mới cần chèn vào cuối vector
        void push_back(T newElement) {
            // Gấp đôi dung lượng nếu vector đã đầy
            if (Size == capacity)
                expand(2 * Size);
            // Chèn phần tử mới vào ngay sau phần tử cuối cùng
            Array[Size] = newElement;
            // Tăng kích thước 1 đơn vị
            Size++;
        }

        void pop_back() {
            Size--;
        }

        ~vector()
        {
            //cout<<"Xoa vung nho :"<<Array<<endl;
            delete[] Array;
        }
};


void khoi_tao_tach_phantu(string &trungto,vector <string> &X)
{
    // Xóa hết các kí tự trắng thừa trên chuỗi trung tố
    while (trungto.find(" ") != -1)
    {
        trungto.erase(trungto.find(" "),1);
    }

    // Lính canh để tách chuỗi
    // (12+8)*3/6+5-99
    trungto = trungto + '$';
    // '(12+8)*3/6+5-99'+'$' => (12+8)*3/6+5-99+1000$
    // Ở đây ta thấy luật nếu là là số hoặc khác số ta thực hiên
    // Lưu nó vào vector phần tử và nó là 1 phần tử số hoặc là toán hạng
    // Khi nó gặp kí tự $ nó sẽ ngừng việc xét
    // Để phát hiện việc đó ta dùng hàm isdigit(trungto[i])
    string new_ptu = "";
    for (int i =0;i<trungto.size(); i++)
    {
        if (isdigit(trungto[i]) == true)
            {
                new_ptu = new_ptu + trungto [i];
            }
        else
            {
                if (new_ptu != "") X.push_back(new_ptu);//,cout<<new_ptu<<endl;
                new_ptu = "";
                new_ptu = new_ptu+trungto[i];
                X.push_back(new_ptu);//,cout<<trungto[i]<<endl;
                new_ptu = "";
            }
    }
    // Xóa phần tử lính canh ở cuối vector
    X.pop_back();
}

int uuTien(string x)
{
    if (x == "(") return -1;
	if (x == "+" || x == "-" ) return 0;
	if (x == "*" || x == "/" ) return 1;
	return 2;
}

void trungto2hauto(vector <string> &x,vector <string> &y)
{
    stack <string> toantu;
    for (int i = 0; i<x.size(); i++)
    {
        // Nếu nó là toán hạng thì đẩy nó vào vector chứa kết quả dạng hậu tố
        if ( isdigit(x[i][0]) == true ) { y.push_back(x[i]); }
        //Nếu nó là dấu mở ngoặc đưa nó vào stack
        else if ( x[i] == "(" )
        {
            toantu.push(x[i]);
        }
            /*
            Nếu gặp dấu đóng ngoặc thì cứ lấy các toán tử trong ngăn xếp ra và
            ghi vào kết quả cho đến khi lấy được dấu mở ngoặc ra khỏi ngăn xếp.
            */
        else if ( x[i] == ")" )
        {
            while (toantu.top() != "(" )
            {
                y.push_back(toantu.top());
                toantu.pop();
            }
            toantu.pop();

        }
            // Nếu nó là toán tử +,-,*,/ thì làm 2 việc sau
        else if ( uuTien(x[i]) >=0 && uuTien(x[i])<=1)
        {
            /*
            Chừng nào còn có một toán tử o2 ở đỉnh ngăn xếp và độ ưu tiên
            của o1 ≤ độ ưu tiên của o2 thì lấy o2 ra khỏi ngăn xếp
            và ghi vào kết quả.
            */

            while ( !toantu.empty() && uuTien(x[i]) <= uuTien(toantu.top()) )
                {

                    y.push_back(toantu.top());
                    toantu.pop();
                }
            // Đẩy toán tử đang xét vào stack
            toantu.push(x[i]);
        }


    }

    /*
    Khi đã duyệt hết biểu thức trung tố, lần lượt lấy tất cả toán hạng (nếu có)
    từ ngăn xếp ra và ghi vào chuỗi kết quả.
    */
    while (!toantu.empty())
    {
         y.push_back(toantu.top());
         toantu.pop();
    }
}

double Process(vector <string> &hauto)
{
    // Thực hiện đẩy hậu tố vào stack
    // Nếu gặp toán tử thì pop 2 phần tử ra và thực hiện với toán tử vừa xét
    // pop lần 1 là bên phải toán tử
    // pop lần 2 là bên trái toán tử
    stack <double> calc;
    for (int i = 0; i<hauto.size(); i++)
    {
        if (uuTien(hauto[i]) >=0 && uuTien(hauto[i])<=1)
            {
                // Biểu thức a <+,-,*,/> b
                float b = calc.top(); calc.pop();
                float a = calc.top(); calc.pop();
                float c;
                if (hauto[i] == "+") {c = a + b; //cout<<endl<<a<<"+"<<b;
                    }
                else if (hauto[i] == "-") {c = a - b; //cout<<endl<<a<<"-"<<b;
                    }
                else if (hauto[i] == "*") {c = a * b; //cout<<endl<<a<<"*"<<b;
                    }
                else if (hauto[i] == "/") {c = a/b; //cout<<endl<<a<<"/"<<b;
                    }
                calc.push(c);
            }
        else
            {
                // Chuyển chuỗi p về số bằng hàm stoi có sẵn trong thư viên chuẩn c++11
                float p = float(stoi(hauto[i]));
                calc.push(p);
            }
    }
    return calc.top();
}

void chucnang()
{
        string s = "";
        vector <string> trungTo; vector <string> hauTo;
        cout<<"Moi nhap bieu thuc can tinh:";
        getline(cin,s);

        khoi_tao_tach_phantu(s,trungTo);

        cout<<"Trung to: ";
        for (int i = 0; i<trungTo.size(); i++) cout<<trungTo[i];
        trungto2hauto(trungTo,hauTo);

        cout<<endl<<"Hau to: ";
        for (int i = 0; i<hauTo.size(); i++) cout<<hauTo[i]<<" ";

        cout<<endl<<"Gia tri bieu thuc: "<<Process(hauTo);
}

int main()
{
    int thoat = 1;

    cout<<"CHUONG TRINH DEMO KY PHAP BA LAN NGUOC!"<<endl;

    while (thoat == 1)
    {
        chucnang();
        cout<<endl<<"Ban co muon tiep tuc? Nhap 0 de thoat! 1 de tiep tuc:"; cin>>thoat;
        cin.ignore();
        system("cls");
    }

    return 0;
}
